#!/usr/bin/env python
# -*- coding: utf-8 -*-
from ._size_hint import size_hint


__all__ = ['size_hint']
