#!/usr/bin/env python
# -*- coding: utf-8 -*-
from ._setup import mpl_setup

mpl_setup('pgf')
