import io
import sys
import re
from setuptools import setup, find_packages
from setuptools.command.test import test as TestCommand

with open('mplmagic/__init__.py') as fd:
    __version__ = re.search("__version__ = '(.*)'", fd.read()).group(1)

setup(
    name='mplmagic',
    version=__version__,
    url='https://tangshan.cosx-isinx.org/gitlab/tang/mplmagic',
    license='All rights reserved',
    author='Yu-Hang Tang',
    # tests_require=['tox'],
    install_requires=['ipython', 'matplotlib'],
    extras_require={},
    # cmdclass={'test': Tox},
    author_email='Tang.Maxin@gmail.com',
    description='Matplotlib magic header for easy switch between pgf and svg backends',
    long_description="",
    long_description_content_type="text/markdown",
    packages=find_packages(exclude='test'),
    package_data={
        'mplmagic': [],
    },
    # include_package_data=True,
    platforms='any',
    classifiers=[
        'Programming Language :: Python',
    ]
)
