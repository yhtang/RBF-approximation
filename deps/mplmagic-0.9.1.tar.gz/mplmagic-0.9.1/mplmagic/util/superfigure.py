#!/usr/bin/env python
# -*- coding: utf-8 -*-
from sympy import symbols, nonlinsolve
from matplotlib.figure import Figure
from matplotlib.axes import Axes
from mpl_toolkits.mplot3d import Axes3D


class SuperFigure(Figure):
    def __init__(self, fig):
        self.__dict__.update(**fig.__dict__)

    @property
    def width_to_height(self):
        return self.get_figwidth() / self.get_figheight()

    def make_axes(self, left=None, right=None, top=None, bottom=None,
                  width=None, height=None, width_to_height=None,
                  style=None, **kwargs):
        '''

        Parameters
        ----------
        style: None or 'modern' or 'blank'
            Artistic style of the axes
        '''
        # solve for axes position
        # left, right, top, bottom, width, height, aspect_ratio
        l, r, t, b, w, h, a = symbols('l r t b w h a', real=True)
        eqns = [w + l - r, h + t - b, w - h * a]
        if left is not None:
            eqns.append(l - left)
        if right is not None:
            eqns.append(r - right)
        if top is not None:
            eqns.append(t - top)
        if bottom is not None:
            eqns.append(b - bottom)
        if width is not None:
            eqns.append(w - width)
        if height is not None:
            eqns.append(h - height)
        if width_to_height is not None:
            eqns.append(w / h - width_to_height / self.width_to_height)
        unknowns = [l, r, t, b, w, h, a]
        try:
            sols, = nonlinsolve(eqns, unknowns)
            left = float(sols[0])
            right = float(sols[1])
            top = float(sols[2])
            bottom = float(sols[3])
            width = float(sols[4])
            height = float(sols[5])
            width_to_height = float(sols[6])
        except (TypeError, ValueError):
            raise RuntimeError('Cannot determine axes position!')

        if 'projection' in kwargs:
            BaseAxes = Axes3D
            kwargs.pop('projection')
            kwargs['auto_add_to_figure'] = False
        else:
            BaseAxes = Axes

        class SuperAxes(BaseAxes):

            def __init__(self, fig, rect=None, *args, **kwargs):
                if rect is None:
                    rect = [0.0, 0.0, 1.0, 1.0]
                super().__init__(fig, rect, *args, **kwargs)
                fig.add_axes(self)

            @property
            def x0(self):
                return self.get_position().x0

            @property
            def width(self):
                return self.get_position().width

            @property
            def y0(self):
                return 1 - (self.get_position().y0 + self.get_position().height)

            @property
            def height(self):
                return self.get_position().height

            @property
            def left(self):
                return self.x0

            @property
            def top(self):
                return self.y0

            @property
            def x1(self):
                return self.x0 + self.width

            @property
            def y1(self):
                return self.y0 + self.height

            @property
            def right(self):
                return self.x1

            @property
            def bottom(self):
                return self.y1

        ax = SuperAxes(self, [left, 1 - bottom, width, height], **kwargs)

        if style == 'modern':
            for _, sp in ax.spines.items():
                sp.set_visible(False)
            ax.patch.set_facecolor('#F0F0F0')
            ax.tick_params(axis='both', direction='in', width=0.5, length=2)
        elif style == 'blank':
            ax.axes.axis('off')
            ax.axes.set_xlim([0, 1])
            ax.axes.set_ylim([0, 1])

        return ax
