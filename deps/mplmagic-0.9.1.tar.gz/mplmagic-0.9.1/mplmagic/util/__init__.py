#!/usr/bin/env python
# -*- coding: utf-8 -*-
import matplotlib.pyplot as plt
from .superfigure import SuperFigure


__all__ = ['SuperFigure']


def size_hint(figure_width, figure_height,
              page_width=8.5, page_height=11.0,
              margin_left=0.75, margin_top=0.75):

    fig = SuperFigure(plt.figure(figsize=(page_width, page_height), dpi=110))
    ax_letter = fig.add_axes([0, 0, 1, 1], zorder=-100)
    ax_letter.axis('off')
    ax_letter.axhline(0, ls='dashed', color='k')
    ax_letter.axhline(1, ls='dashed', color='k')
    ax_letter.axvline(0, ls='dashed', color='k')
    ax_letter.axvline(1, ls='dashed', color='k')
    ax_letter.axis([0, 1, 0, 1])

    ax_figure = fig.add_axes([margin_left / page_width,
                              1 - (margin_top + figure_height) / page_height,
                              figure_width / page_width,
                              figure_height / page_height])
    for _, spine in ax_figure.spines.items():
        spine.set_visible(False)
    ax_figure.set_xticks([])
    ax_figure.set_yticks([])
    ax_figure.set_facecolor((0.85, 0.85, 0.85))

    return fig
