#!/usr/bin/env python
# -*- coding: utf-8 -*-
from IPython import get_ipython

__version__ = '0.9.1'


def mpl_setup(backend):

    if backend == 'svg':
        get_ipython().run_line_magic('matplotlib', 'inline')
        get_ipython().run_line_magic('config',
                                     "InlineBackend.figure_format = 'svg'")

    import matplotlib

    matplotlib.rcParams['font.family'] = 'sans-serif'
    matplotlib.rcParams['font.weight'] = 'normal'

    # "Fonts not found" despite in fc-list: delete .cache/matplotlib
    # MPL may mistaken 'thin' fonts as 'regular', workaround:
    #     delete the 'thin' variants
    matplotlib.rcParams['font.serif'] = 'Lora'
    matplotlib.rcParams['font.sans-serif'] = 'D-DIN'
    matplotlib.rcParams['font.monospace'] = 'Fira Code'

    matplotlib.rcParams['lines.linewidth'] = 0.5

    tex_common_preamble = r"""
    \usepackage{amsmath,amstext}
    \usepackage{mathtools}
    \usepackage{amssymb}
    \usepackage{amsbsy}
    \usepackage{gensymb}
    \usepackage{wasysym}
    """

    if backend == 'svg':

        matplotlib.rcParams['text.latex.preamble'] = tex_common_preamble

    elif backend == 'pgf':

        matplotlib.use('pgf')
        matplotlib.rcParams['pgf.texsystem'] = 'xelatex'

        # Don't specify fonts in final .pgf output, leave it to compilation
        matplotlib.rcParams['pgf.rcfonts'] = False

        matplotlib.rcParams['pgf.preamble'] = tex_common_preamble + r"""
        \usepackage{fontspec}
        \setmainfont{Lora}
        \setsansfont{D-DINCondensed}
        \setmonofont{Fira Code}
        \usepackage[T1]{fontenc}
        \newcommand{\tl}[2]{\textsc{\addfontfeature{LetterSpace=#1} #2}}
        """

    else:

        raise ValueError('Unknown backend "%s"' % backend)
