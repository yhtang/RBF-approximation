#!/usr/bin/env python
# -*- coding: utf-8 -*-
from . import mpl_setup

mpl_setup('svg')